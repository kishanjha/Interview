package com.zycus.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.dao.impl.SystemUserDaoImpl;
import com.zycus.model.SystemUser;

@Service
public class SystemUserServiceImpl {
 
	@Autowired
	SystemUserDaoImpl systemUserDaoImpl;
	
	
	public void setSystemUserDaoImpl(SystemUserDaoImpl systemUserDaoImpl) {
		this.systemUserDaoImpl = systemUserDaoImpl;
	}

	@Transactional
	public boolean Register(SystemUser systemUser) {
		return systemUserDaoImpl.Register(systemUser);
	}

	public SystemUser login(String emailId,String password) {
		return systemUserDaoImpl.login(emailId,password);
	}
}
