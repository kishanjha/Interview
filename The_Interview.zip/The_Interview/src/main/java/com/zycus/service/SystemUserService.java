package com.zycus.service;

import org.springframework.stereotype.Service;

import com.zycus.model.SystemUser;

@Service
public interface SystemUserService {
	public boolean Register(SystemUser systemUser);
	public SystemUser login(String emailId,String password);
}
