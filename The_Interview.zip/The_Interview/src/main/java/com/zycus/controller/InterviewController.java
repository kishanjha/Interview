package com.zycus.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.zycus.model.SystemUser;
import com.zycus.service.SystemUserService;
import com.zycus.service.impl.SystemUserServiceImpl;

@Controller
public class InterviewController {

	@Autowired
	SystemUserServiceImpl userService;

	public void setUserService(SystemUserServiceImpl userService) {
		this.userService =userService;
	}

	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	public String getHomePage() {
		return "index";
	}

	@RequestMapping(value = "/newUser", method = RequestMethod.GET)
	public String getSignUpPage(Model model) {
		model.addAttribute("SystemUserObj", new SystemUser());
		return "newUser";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processSignUp(@ModelAttribute("SystemUserObj") SystemUser systemUser, Model model) {
		boolean status = userService.Register(systemUser);
		if (status) {
			model.addAttribute("message", "Registration successful");
			return "index";
		}
		model.addAttribute("message", "Registration Unsuccessful");
		return "newUser";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String getLoginPage(Model model) {
		model.addAttribute("SystemUserObj", new SystemUser());
		return "login";
	}

	@RequestMapping(value = "/loginprocess", method = RequestMethod.POST)
	public String processlogin(@ModelAttribute("SystemUserObj") SystemUser systemUser, Model model,
			HttpSession httpSession) {
		SystemUser systemUserNew = userService.login(systemUser.getUserEmailId(), systemUser.getUserPassword());
		if (systemUserNew != null) {
			httpSession.setAttribute("SystemUserSessionObj", systemUserNew);
			model.addAttribute("message", "login successful");
			return "index";
		}
		model.addAttribute("message", "login Unsuccessful");
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logOut(Model model, HttpSession httpSession) {
		httpSession.invalidate();
		model.addAttribute("message", "loggedOut successfully");
		return "index";
	}

}
