package com.zycus.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.zycus.model.SystemUser;

@Repository
public class SystemUserDaoImpl {
	@Autowired
	HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	public boolean Register(SystemUser systemUser) {
		Integer id=(Integer) hibernateTemplate.save(systemUser);
		if(id!=null)
			return true;
		
		return false;
	}
	
	public SystemUser login(String emailId,String password) {
		String query="from SystemUser where userEmailId=? and userPassword=?";
		System.out.println("hello kishan");
		List<SystemUser> listSystemUser=(List<SystemUser>) hibernateTemplate.find(query,
				new Object[] {emailId,password});
		if(listSystemUser.size()==1) {
			System.out.println(listSystemUser.get(0));
			return listSystemUser.get(0);
		}
		return null;
	}
	

}
