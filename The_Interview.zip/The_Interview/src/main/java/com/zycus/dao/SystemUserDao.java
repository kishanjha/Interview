package com.zycus.dao;

import org.springframework.stereotype.Repository;

import com.zycus.model.SystemUser;

@Repository
public interface SystemUserDao {

	public boolean Register(SystemUser systemUser);
	public SystemUser login(String emailId, String password);
}
