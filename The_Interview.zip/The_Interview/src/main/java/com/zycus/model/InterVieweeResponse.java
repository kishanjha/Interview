package com.zycus.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class InterVieweeResponse {
	@Id
	int responseId;
	int questionId;
	int sessionId;
	int evoluation;
	String comment;

	public InterVieweeResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

	public int getSessionId() {
		return sessionId;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}

	public int getEvoluation() {
		return evoluation;
	}

	public void setEvoluation(int evoluation) {
		this.evoluation = evoluation;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "InterVieweeResponse [questionId=" + questionId + ", sessionId=" + sessionId + ", evoluation="
				+ evoluation + ", comment=" + comment + "]";
	}

}
