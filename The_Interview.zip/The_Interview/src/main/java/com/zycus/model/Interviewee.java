package com.zycus.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Interviewee {
	@Id
	@GeneratedValue
	int intervieweeId;
	String intervieweeName;
	String intervieweeEmailId;
	String intervieweeMobile;
	String intervieweeDesignation;
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Interview_Question", joinColumns = {
			@JoinColumn(name = "intervieweeId") }, inverseJoinColumns = { @JoinColumn(name = "questionId") })
	Set<Question> questions;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Interview_Session", joinColumns = {
			@JoinColumn(name = "intervieweeId") }, inverseJoinColumns = { @JoinColumn(name = "sessionId") })
	Set<Session> sessions;

	public Interviewee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getIntervieweeId() {
		return intervieweeId;
	}

	public void setIntervieweeId(int intervieweeId) {
		this.intervieweeId = intervieweeId;
	}

	public String getIntervieweeName() {
		return intervieweeName;
	}

	public void setIntervieweeName(String intervieweeName) {
		this.intervieweeName = intervieweeName;
	}

	public String getIntervieweeEmailId() {
		return intervieweeEmailId;
	}

	public void setIntervieweeEmailId(String intervieweeEmailId) {
		this.intervieweeEmailId = intervieweeEmailId;
	}

	public String getIntervieweeMobile() {
		return intervieweeMobile;
	}

	public void setIntervieweeMobile(String intervieweeMobile) {
		this.intervieweeMobile = intervieweeMobile;
	}

	public String getIntervieweeDesignation() {
		return intervieweeDesignation;
	}

	public void setIntervieweeDesignation(String intervieweeDesignation) {
		this.intervieweeDesignation = intervieweeDesignation;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public Set<Session> getSessions() {
		return sessions;
	}

	public void setSessions(Set<Session> sessions) {
		this.sessions = sessions;
	}

	@Override
	public String toString() {
		return "Interviewee [intervieweeId=" + intervieweeId + ", intervieweeName=" + intervieweeName
				+ ", intervieweeEmailId=" + intervieweeEmailId + ", intervieweeMobile=" + intervieweeMobile
				+ ", intervieweeDesignation=" + intervieweeDesignation + ", questions=" + questions + ", sessions="
				+ sessions + "]";
	}

}
