package com.zycus.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class SystemUser {
	@Id
	@GeneratedValue
	int userId;
	String userName;
	@Column(unique = true, nullable = false)
	String userEmailId;
	String userPassword;
	String accessibility;
	
	public SystemUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getAccessibility() {
		return accessibility;
	}
	public void setAccessibility(String accessibility) {
		this.accessibility = accessibility;
	}
	@Override
	public String toString() {
		return "SystemUser [userId=" + userId + ", userName=" + userName + ", userEmailId=" + userEmailId
				+ ", userPassword=" + userPassword + ", accessibility=" + accessibility + "]";
	}
	
	

}
