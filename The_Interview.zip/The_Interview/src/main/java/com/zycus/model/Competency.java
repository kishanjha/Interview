package com.zycus.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Competency {
	@Id
	@GeneratedValue
	int competencyId;
	String competencyName;

	public Competency() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCompetencyId() {
		return competencyId;
	}

	public void setCompetencyId(int competencyId) {
		this.competencyId = competencyId;
	}

	public String getCompetencyName() {
		return competencyName;
	}

	public void setCompetencyName(String competencyName) {
		this.competencyName = competencyName;
	}


	@Override
	public String toString() {
		return "Competency [competencyId=" + competencyId + ", competencyName=" + competencyName + "]";
	}

}
