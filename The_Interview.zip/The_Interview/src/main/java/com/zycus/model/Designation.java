package com.zycus.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Designation {
	@Id
	@GeneratedValue
	int designationId;
	String designationName;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "Designation_Competency", joinColumns = { @JoinColumn(name = "designationId") }, inverseJoinColumns = { @JoinColumn(name = "competencyId") })
	Set<Competency> listCompetency;

	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDesignationId() {
		return designationId;
	}

	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}

	public String getDesignationName() {
		return designationName;
	}

	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}

	public Set<Competency> getListCompetency() {
		return listCompetency;
	}

	public void setListCompetency(Set<Competency> listCompetency) {
		this.listCompetency = listCompetency;
	}

	@Override
	public String toString() {
		return "Designation [designationId=" + designationId + ", designationName=" + designationName
				+ ", listCompetency=" + listCompetency + "]";
	}

}
